import { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Send, CheckCircle2 } from "lucide-react";

export default function SubmitProposal() {
  const [form, setForm] = useState({
    contact_name: "",
    contact_email: "",
    organization: "",
    study_title: "",
    proposal: "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.contact_name || !form.contact_email || !form.study_title || !form.proposal) {
      setError("Please complete all required fields.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await base44.entities.StudyProposal.create({
        contact_name: form.contact_name,
        contact_email: form.contact_email,
        organization: form.organization || null,
        study_title: form.study_title,
        proposal: form.proposal,
      });
      setDone(true);
    } catch (err) {
      setError(err.message || "Submission failed. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (done) {
    return (
      <div className="max-w-xl mx-auto text-center py-16">
        <div className="w-12 h-12 rounded-full bg-[#14b8a6]/10 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 className="w-6 h-6 text-[#14b8a6]" />
        </div>
        <h1 className="font-heading text-2xl font-semibold text-primary">Proposal received</h1>
        <p className="mt-3 text-sm text-slate-600 leading-relaxed">
          Thank you for your interest. Our research team will review your proposal and reach out using the
          contact details you provided.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 mt-6 text-sm text-primary underline"
        >
          <ArrowLeft className="w-4 h-4" /> Back to studies
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-xl">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-primary transition-colors mb-6">
        <ArrowLeft className="w-4 h-4" /> All studies
      </Link>

      <header className="border-b border-slate-200 pb-6">
        <div className="text-xs uppercase tracking-wide text-[#14b8a6] font-semibold mb-2">Research Proposal</div>
        <h1 className="font-heading text-3xl font-semibold text-primary tracking-tight">Submit a study proposal</h1>
        <p className="mt-3 text-sm text-slate-600 leading-relaxed">
          Have an idea for a study? Share your contact information and a brief proposal. Our team will review
          it and follow up.
        </p>
      </header>

      <form onSubmit={submit} className="mt-6 rounded-lg border border-slate-200 p-6 space-y-5 bg-white">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Your name <span className="text-destructive">*</span></Label>
            <Input value={form.contact_name} onChange={(e) => set("contact_name", e.target.value)} required placeholder="Full name" />
          </div>
          <div className="space-y-2">
            <Label>Email <span className="text-destructive">*</span></Label>
            <Input type="email" value={form.contact_email} onChange={(e) => set("contact_email", e.target.value)} required placeholder="you@example.com" />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Organization (optional)</Label>
          <Input value={form.organization} onChange={(e) => set("organization", e.target.value)} placeholder="University, lab, company..." />
        </div>

        <div className="space-y-2">
          <Label>Study title <span className="text-destructive">*</span></Label>
          <Input value={form.study_title} onChange={(e) => set("study_title", e.target.value)} required placeholder="A short title for your proposed study" />
        </div>

        <div className="space-y-2">
          <Label>Brief proposal <span className="text-destructive">*</span></Label>
          <Textarea
            value={form.proposal}
            onChange={(e) => set("proposal", e.target.value)}
            required
            rows={6}
            placeholder="Describe the goal, what data you'd collect, and why it matters..."
          />
        </div>

        {error && <div className="text-sm text-destructive">{error}</div>}

        <Button type="submit" disabled={saving} className="w-full sm:w-auto">
          <Send className="w-4 h-4 mr-2" /> {saving ? "Sending..." : "Submit proposal"}
        </Button>
      </form>
    </div>
  );
}